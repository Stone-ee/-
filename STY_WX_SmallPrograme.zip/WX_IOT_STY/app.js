// app.js
App({
  onLaunch() {

  },
  globalData: {
    userInfo: null
  }
})
