// index.js
// 获取应用实例


Page({
  data: {
    uid:"5c372ee98bfbafb882573566c8577efe",//用户密钥，巴法云控制台获取
    ledtopic:"LED001",//控制报警灯的主题
    fantopic:"FAN",//控制空调的主题
    inftopic:"infred",//控制窗帘的主题
    datatopic:"GetData",//感知信息的主题

    LED001:'red', //默认状态关闭,感知设备指示红点
    LED002:'red', //默认状态关闭,执行设备指示红点
    Text_1:'离线',//默认状态离线,执行设备指示红点
    Text_2:'离线',//默认状态离线,执行设备指示红点

    temprature:'25',  //温度数据
    lightclass:'1',   //光强数据
    PM25:'30',        //PM2.5数据
    humidty:'30',     //湿度数据

    ledicon:'../../pic/lightoff.png',
    fanicon:'../../pic/fanoff.png',
    inficon:'../../pic/toneoff.jpg',
    checkled:false,
    checkinfared:false,
    checkfan:false
  },
/**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    wx.stopPullDownRefresh()
    wx.vibrateLong({
      success: () => {},
    })
    this.datarefresh()
  },
  datarefresh(){

    var that = this

    wx.showLoading({
      title: '正在刷新数据',
    })

    wx.request({
      url: 'https://api.bemfa.com/api/device/v1/data/1/get/',
      data: {
        uid: that.data.uid,
        topic: that.data.datatopic,
        num:1
      },
      header: {
        'content-type': "application/x-www-form-urlencoded"
      },
      success (res) {
        console.log(res)
        if(res.data.msg.indexOf("$") != -1){//如果数据里包含#号，表示获取的是传感器值，因为单片机上传数据的时候用$号进行了包裹
          //如果有$号就进行字符串分割
          var all_data_arr = res.data.msg.split("$"); //分割数据，并把分割后的数据放到数组里。
          console.log(all_data_arr)//打印数组
          that.setData({ //数据赋值给变量
            temprature:all_data_arr[1],//赋值温度
            humidty:all_data_arr[2], //赋值湿度
            lightclass:all_data_arr[3], //赋值光强
            PM25:all_data_arr[4], //赋值PM2.5
          })
        }
        wx.showToast({
          title: '刷新成功',
          icon:'success',
          duration:800
        })
      }
    })
  },

onchange1({detail}){
      console.log('报警灯状态:'+detail.value)
      var that =this
      wx.vibrateShort({
        type: 'heavy',
      })
      wx.showLoading({
        title: '指令下发中',
      })

      //发起网络请求
      wx.request({
        url: 'https://api.bemfa.com/api/device/v1/data/1/push/post/',
        method:"POST",
        data:{
          uid:  that.data.uid,
          topic: that.data.ledtopic,
          msg: "#"+detail.value
        },
        header:{
          'content-type': "application/x-www-form-urlencoded"
        },
        success(res){
          console.log(res.data)
          if(res.data.status == "sendok"){
            wx.showToast({
              title: '指令下发成功',
              icon:'success',
              duration:1000
            })
          }else{
            wx.hideLoading({
              success: () => { },
            })
            wx.showModal({
              title: '提示',
              content: res.data.status+'  : 请修改对应参数',
              success (res) {
                if (res.confirm) {
                  console.log('用户点击确定')
                } else if (res.cancel) {
                  console.log('用户点击取消')
                }
              }
            })
            
          }
        }
      })


      if(detail.value == true)
      {
        that.setData({
          checkled:true,
          ledicon:'../../pic/lighton.png'
        })
      }
      else
      {
        that.setData({
          checkled:false,
          ledicon:'../../pic/lightoff.png'
        })
      }
      
},
onchange2({detail}){
    
    console.log('空调的状态:'+detail.value)
    var that =this
    wx.vibrateShort({
      type: 'heavy',
    })
    wx.showLoading({
      title: '指令下发中',
    })

 //发起网络请求
      wx.request({
        url: 'https://api.bemfa.com/api/device/v1/data/1/push/post/',
        method:"POST",
        data:{
          uid:  that.data.uid,
          topic: that.data.fantopic,
          msg: detail.value
        },
        header:{
          'content-type': "application/x-www-form-urlencoded"
        },
        success(res){
          console.log(res.data)
          if(res.data.status == "sendok"){
            wx.showToast({
              title: '指令下发成功',
              icon:'success',
              duration:1000
            })
          }else{
            wx.hideLoading({
              success: () => { },
            })
            wx.showModal({
              title: '提示',
              content: res.data.status+'  : 请修改对应参数',
              success (res) {
                if (res.confirm) {
                  console.log('用户点击确定')
                } else if (res.cancel) {
                  console.log('用户点击取消')
                }
              }
            })
            
          }
        }
      })
    if(detail.value == true)
    {
      that.setData({
        checkinfan:true,
        fanicon:'../../pic/fanon.png'
      })
    }
    else
    {
      that.setData({
        checkinfan:false,
        fanicon:'../../pic/fanoff.png'
      })
    }
   
},
onchange3({detail}){
  console.log('窗帘的状态:'+detail.value)
  var that =this
  wx.vibrateShort({
    type: 'heavy',
  })
  wx.showLoading({
    title: '指令下发中',
    
  })
  
 //发起网络请求
 wx.request({
  url: 'https://api.bemfa.com/api/device/v1/data/1/push/post/',
  method:"POST",
  data:{
    uid:   that.data.uid,
    topic: that.data.inftopic,
    msg:   detail.value
  },
  header:{
    'content-type': "application/x-www-form-urlencoded"
  },
  success(res){
    console.log(res.data)
    if(res.data.status == "sendok"){
      wx.showToast({
        title: '指令下发成功',
        icon:'success',
        duration:1000
      })
    }else{
      wx.hideLoading({
        success: () => { },
      })
      wx.showModal({
        title: '提示',
        content: res.data.status+'  : 请修改对应参数',
        success (res) {
          if (res.confirm) {
            console.log('用户点击确定')
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      })
      
    }
  }
})

  if(detail.value == true)
  {
    that.setData({
      checkinfared:true,
      inficon:'../../pic/toneon.jpg'
    })
  }
  else
  {
    that.setData({
      checkinfared:false,
      inficon:'../../pic/toneoff.jpg'
    })
  }
},
onLoad() {
  var that = this
  //设置定时器,每3S请求一次数据
  setInterval(() => {
    //this.datarefresh()
    //刷新数据
    wx.request({
      url: 'https://api.bemfa.com/api/device/v1/data/1/get/',
      data: {
        uid: that.data.uid,
        topic: that.data.datatopic,
        num:1
      },
      header: {
        'content-type': "application/x-www-form-urlencoded"
      },
      success (res) {
 //       console.log(res)
        if(res.data.msg.indexOf("$") != -1){//如果数据里包含#号，表示获取的是传感器值，因为单片机上传数据的时候用$号进行了包裹
          //如果有$号就进行字符串分割
          var all_data_arr = res.data.msg.split("$"); //分割数据，并把分割后的数据放到数组里。
  //        console.log(all_data_arr)//打印数组
          that.setData({ //数据赋值给变量
            temprature:all_data_arr[1],//赋值温度
            humidty:all_data_arr[2], //赋值湿度
            lightclass:all_data_arr[3], //赋值光强
            PM25:all_data_arr[4], //赋值PM2.5
          })
        }
      }
    })
    //判断设备状态
    wx.request({
      url: 'https://api.bemfa.com/api/device/v1/status/',
      data:{
        uid: that.data.uid,
        topic: that.data.datatopic,
      },
      header: {
        'content-type': "application/x-www-form-urlencoded"
      },
      success (res) {
       console.log(res)
        if(res.data.status === "online"){
          that.setData({
            LED001: 'green',
            Text_1: '在线',
          })
        }else{
          that.setData({
            LED001: 'red',
            Text_1: '离线',
          })
        }
      }
    })

    wx.request({
      url: 'https://api.bemfa.com/api/device/v1/status/',
      data:{
        uid: that.data.uid,
        topic: that.data.ledtopic,
      },
      header: {
        'content-type': "application/x-www-form-urlencoded"
      },
      success (res) {
       console.log(res)
        if(res.data.status === "online"){
          that.setData({
            LED002: 'green',
            Text_2: '在线',
          })
        }else{
          that.setData({
            LED002: 'red',
            Text_2: '离线',
          })
        }
      }
    })
  }, 100000);
},

// ceshi(){
//   wx.request({
//     url: 'http://192.168.137.177:1883',
//     success(res){
//       console.log(res)
//     },
//     complete(res){
//       console.log(res)
//     }
//   })
// }


})
